package com.Entity.OneToMany_Mapping;

public class Bank {

}
